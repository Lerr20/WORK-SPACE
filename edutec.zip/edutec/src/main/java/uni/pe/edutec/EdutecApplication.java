package uni.pe.edutec;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EdutecApplication {

	public static void main(String[] args) {
		SpringApplication.run(EdutecApplication.class, args);
	}

}
