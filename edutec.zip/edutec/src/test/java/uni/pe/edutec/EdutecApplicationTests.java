package uni.pe.edutec;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EdutecApplicationTests {

	@Test
	void contextLoads() {
	}

}
